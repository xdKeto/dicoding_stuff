// yestoya_lumenchristo_NsI8
/**
 * Goal tahun ini:
 * 1. Belajar JavaScript.
 * 2. Menjadi Front-End atau Back-End Developer.
 */