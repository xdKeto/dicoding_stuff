# Project Front-End Notes App Back-End Fundamentals
Running a project in production:

1. ``npm install``
2. ``npm run build``
3. ``npm run start``
